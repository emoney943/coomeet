<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<title>Coomeet Free Minutes Generator</title>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.6.1/css/pikaday.min.css">
<link rel="stylesheet" href="assets/css/styles.min.css">
<link rel="stylesheet" href="assets/css/custom.css">
<link rel="icon" type="image/x-icon" href="assets/img/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,700;0,800;0,900;1,300;1,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

<script async src="https://www.googletagmanager.com/gtag/js?id=G-GV17F4G49J"></script>
<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'G-GV17F4G49J');
	</script>
</head>
<body>
<nav class="navbar navbar-dark navbar-expand-lg bg-white portfolio-navbar gradient">
<div class="container"><a class="navbar-brand logo" href="#"><font color="white">Coo</font><font style="color: #acfff9;">Meet</font></a><button data-toggle="collapse" class="navbar-toggler" data-target="#navbarNav"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="navbarNav">
<ul class="nav navbar-nav ml-auto">
<li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="#" id="NavPrivacy">Privacy Policy</a></li>
<li class="nav-item"><a class="nav-link" href="#" id="NavContact">Contact Us</a></li>
</ul>
</div>
</div>
</nav>
<main class="page lanidng-page">
<section class="portfolio-block block-intro" style="padding: 25px;">
<div class="container border rounded shadow" style="background: linear-gradient(120deg, rgb(253,253,255) 0%, rgb(240,249,255) 100%), #ffffff;color: rgb(50,50,50);padding: 15px;">
<img src="assets/img/avatars/logo1.png" style="width:150px;margin-bottom:-10px;">
<div id="FirstPanel" class="bounceIn animation-delay-400 animated">
<div>
<p style="margin-bottom: 10px;" class="fontpopins">Get Coomeet Premium Subscription for <strong>Free</strong>. </p>
</div>
<div class="col-md-10 mx-auto">
<input type="email" class="form-control form-control-lg" placeholder="Your coomeet E-mail" style="height: 70px;" id="emlInp" value="">
<label class="mt-2 fontHnin">This tool will enable all the premium features in your coomeet account.</label>
</div>
<div class="about-me"><button class="btn-lg btnRed col-md-10 mx-auto mb-4" type="button" id="ActivatetButtonOne">Activate!</button></div>
</div>

<div id="responsPlace" style="display:none">
<div class="d-flex justify-content-center" style="text-align: center;">
<p class="fontpopins">Searching for the account..</p>
</div>
<center><div class="spinner-grow spinnerStl" role="status"></div></center>
</div>

</div>
</section>
</main>
<section class="portfolio-block website gradient">
<div class="container">
<div class="row align-items-center">
<div class="col-md-12 col-lg-5 offset-lg-1 text">
<h3>Coomeet Unlimited Chat?</h3>
<p>You can use our tool to generate as many minutes you want in the website for Free without paying anything, Just follow the instructions and then you will have your minutes added to your email account in a matter of seconds. If you like this service please share it with your friends.</p>
</div>
<div class="col-md-12 col-lg-5">
<div class="portfolio-laptop-mockup">
<div class="screen">
<div class="screen-content" style="background-image:url(&quot;assets/img/tech/image6.png&quot;);"></div>
</div>
<div class="keyboard"></div>
</div>
</div>
</div>
</div>
</section>
<footer class="page-footer" style="padding-top: 20px;">
<div class="container"> All Rights Reserved © <span id="ThisYear">2021</span>
</div>
</footer>
<script>
		var MLGDate = new Date();
		var MLGYear = MLGDate.getFullYear();
		document.getElementById("ThisYear").innerHTML = MLGYear;
	</script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.6.1/pikaday.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script src="assets/js/ion.sound.min.js"></script>
<script src="assets/js/custom.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
	<!-- $(".resource-select-item").mouseover(function() { -->
		<!-- alert("Hi"); -->
	<!-- }); -->
	
	$("#NavPrivacy").click(function(){
		// Swal.fire('Any fool can use a computer');
	});	
	
	$("#NavContact").click(function(){
		// Swal.fire('Any fool can use a computer');
	});
	
	// Email Validation Function 
	function validateEmail(elementValue){      
		   var emailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
							  
		   return emailPattern.test(elementValue); 
		 } 
	// *************************** //
	
	$("#ActivatetButtonOne").click(function(){
		
		$("#ActivatetButtonOne").attr("disabled",true);
		var ElEmlVal = $("#emlInp").val();

		ion.sound.play("button_click");

		if(!validateEmail(ElEmlVal)){
			
			ion.sound.pause("button_click");
			ion.sound.play("fail");
			
			Swal.fire({
				icon: 'error',
				title: 'Oops...',
				html: 'Please enter a valid E-mail!',
				confirmButtonText: '<i class="fa fa-thumbs-up"></i> Okay!',
				confirmButtonColor: '#2876f1',
			})
			setTimeout(function(){
				$("#ActivatetButtonOne").attr("disabled",false);
				ion.sound.pause("fail");
			},800)
		}else{
			
			ion.sound.play("transition-2");

			$("#FirstPanel").addClass("animated bounceOut");
			
			setTimeout(function(){
					$("#FirstPanel").hide();
					$("#responsPlace").addClass("animated bounceIn");
					$("#responsPlace").fadeIn();
			},600);

			$.post("goOne", {Cml : ElEmlVal}).done(function(data) {
				$("#responsPlace").removeClass("bounceIn");				
				$("#responsPlace").html(data);	
			});
					
		}		
		
	});
	
	</script>
</body>
</html>